CREATE DATABASE  IF NOT EXISTS `bd_banco` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `bd_banco`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bd_banco
-- ------------------------------------------------------
-- Server version	8.0.35

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fecha_nacimiento` date NOT NULL,
  `edad` int NOT NULL,
  `contrasenia` varchar(45) NOT NULL,
  `id_domicilio` int NOT NULL,
  `id_nombre` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `id_domicilio_UNIQUE` (`id_domicilio`),
  UNIQUE KEY `id_nombre_UNIQUE` (`id_nombre`),
  KEY `id_domicilio_idx` (`id_domicilio`),
  KEY `id_nombre_idx` (`id_nombre`),
  CONSTRAINT `id_domicilio` FOREIGN KEY (`id_domicilio`) REFERENCES `domicilio` (`id`),
  CONSTRAINT `id_nombre` FOREIGN KEY (`id_nombre`) REFERENCES `nombre_completo` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (5,'2004-08-02',19,'Manzana123',7,6),(6,'2004-08-02',19,'Manzana123',8,7),(7,'2004-07-06',19,'Pera123',9,8),(8,'2004-07-06',19,'Pera123',10,9),(9,'2004-07-06',19,'Pera123',11,10),(10,'2004-07-06',19,'Guasave005',12,11),(11,'2004-07-06',19,'Manzana777',13,12),(12,'1979-11-12',44,'Vientos777',14,13),(13,'2004-04-04',19,'Gaelo007',15,14),(14,'2004-02-09',20,'SoyPaquito12',16,15),(15,'2000-06-14',23,'MrCalifornia69',17,16),(16,'2004-02-27',19,'ElGaeloesunwey',18,17);
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cuenta`
--

DROP TABLE IF EXISTS `cuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cuenta` (
  `numero_cuenta` int NOT NULL AUTO_INCREMENT,
  `fecha_apertura` date NOT NULL,
  `saldo` decimal(10,0) NOT NULL,
  `id_cliente` int NOT NULL,
  `estado` varchar(45) NOT NULL,
  PRIMARY KEY (`numero_cuenta`),
  UNIQUE KEY `numero_cuenta_UNIQUE` (`numero_cuenta`),
  KEY `id_cliente_idx` (`id_cliente`),
  CONSTRAINT `id_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cuenta`
--

LOCK TABLES `cuenta` WRITE;
/*!40000 ALTER TABLE `cuenta` DISABLE KEYS */;
INSERT INTO `cuenta` VALUES (1,'2024-02-14',1000,8,'Activa'),(2,'2024-02-14',49500,9,'Activa'),(3,'2024-02-14',0,10,'Cancelada'),(7,'2024-02-17',24600,10,'Activa'),(8,'2024-02-17',4000,11,'Activa'),(9,'2024-02-17',80000,12,'Activa'),(10,'2024-02-17',367,13,'Activa'),(11,'2024-02-17',20,14,'Activa'),(12,'2024-02-17',202500,15,'Activa'),(13,'2024-02-19',700,10,'Activa'),(14,'2024-02-19',5000,10,'Activa'),(15,'2024-02-19',7000,10,'Activa'),(16,'2024-02-19',700,10,'Activa'),(17,'2024-02-19',600,10,'Activa'),(18,'2024-02-20',690,10,'Activa'),(19,'2024-02-20',0,10,'Cancelada'),(20,'2024-02-20',460400,10,'Activa'),(21,'2024-02-20',0,16,'Cancelada'),(22,'2024-02-20',1000000,16,'Activa');
/*!40000 ALTER TABLE `cuenta` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `cuenta_before_insert_trigger` BEFORE INSERT ON `cuenta` FOR EACH ROW BEGIN
    SET NEW.fecha_apertura = CURDATE();
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `domicilio`
--

DROP TABLE IF EXISTS `domicilio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `domicilio` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calle` varchar(50) NOT NULL,
  `codigo_postal` int NOT NULL,
  `numero_exterior` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `domicilio`
--

LOCK TABLES `domicilio` WRITE;
/*!40000 ALTER TABLE `domicilio` DISABLE KEYS */;
INSERT INTO `domicilio` VALUES (4,'Alfonso Reyes',85150,644),(5,'Alfonso Reyes',85150,644),(6,'Alfonso Reyes',85150,644),(7,'Alfonso Reyes',85150,644),(8,'Alfonso Reyes',85150,644),(9,'Moises Vazquez',85150,507),(10,'Moises Vazquez',85150,507),(11,'Moises Vazquez',85150,507),(12,'Manuel M. Ponce',81020,116),(13,'Manuel M. Ponce',81020,116),(14,'Pobregon2',77777,5),(15,'Guasaveee',81000,765),(16,'Guasave87',98000,123),(17,'CalleLaMexico',4545445,333),(18,'Muzquiz',85154,2010),(19,'Moises Vazquez',85130,507),(20,'Moises Vazquez',85130,507),(21,'Moises Vazquez',85130,507);
/*!40000 ALTER TABLE `domicilio` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nombre_completo`
--

DROP TABLE IF EXISTS `nombre_completo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nombre_completo` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombres` varchar(50) NOT NULL,
  `apellido_paterno` varchar(20) NOT NULL,
  `apellido_materno` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nombre_completo`
--

LOCK TABLES `nombre_completo` WRITE;
/*!40000 ALTER TABLE `nombre_completo` DISABLE KEYS */;
INSERT INTO `nombre_completo` VALUES (3,'Gael Rafael','Castro','Molina'),(4,'Gael Rafael','Castro','Molina'),(5,'Gael Rafael','Castro','Molina'),(6,'Gael Rafael','Castro','Molina'),(7,'Gael Rafael','Castro','Molina'),(8,'Oliver','Inzunza','Valle'),(9,'Oliver','Inzunza','Valle'),(10,'Oliver','Inzunza','Valle'),(11,'Oliver','Inzunza','Valle'),(12,'Oliver','Inzunza','Valle'),(13,'Carlos Alberto','Gonzalez','Vega'),(14,'Gael Rafael','Castro','Molina'),(15,'Paco','Paquito','Paquitito'),(16,'Jullian','Puerta','null'),(17,'Carlos','Clark','Aviles'),(18,'Oliver','Inzunza','Valle'),(19,'Oliver','Inzunza','Valle'),(20,'Oliver','Inzunza','Valle');
/*!40000 ALTER TABLE `nombre_completo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `retiro_sin_cuenta`
--

DROP TABLE IF EXISTS `retiro_sin_cuenta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `retiro_sin_cuenta` (
  `id_transaccion_ret` int NOT NULL,
  `contrasenia` varchar(8) NOT NULL,
  PRIMARY KEY (`id_transaccion_ret`),
  UNIQUE KEY `id_transaccion_UNIQUE` (`id_transaccion_ret`),
  CONSTRAINT `id_transaccion_ret` FOREIGN KEY (`id_transaccion_ret`) REFERENCES `transaccion` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `retiro_sin_cuenta`
--

LOCK TABLES `retiro_sin_cuenta` WRITE;
/*!40000 ALTER TABLE `retiro_sin_cuenta` DISABLE KEYS */;
INSERT INTO `retiro_sin_cuenta` VALUES (12,'42731807'),(13,'94550546'),(14,'22559770'),(15,'37358004'),(16,'64674841'),(17,'90619867'),(18,'21546496'),(19,'86240636'),(20,'50125110'),(21,'58485227'),(22,'18762634'),(23,'38858203'),(24,'32252449'),(25,'43204703'),(26,'24212441'),(27,'32722190'),(28,'91997387'),(29,'32504408'),(30,'80809150'),(31,'17867685'),(32,'13717498'),(33,'73515505'),(34,'10774784'),(35,'48733050'),(36,'47829440'),(37,'34531580'),(38,'77392200'),(39,'91438255'),(50,'62774042'),(52,'22591079'),(53,'59070521'),(55,'24564200');
/*!40000 ALTER TABLE `retiro_sin_cuenta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaccion`
--

DROP TABLE IF EXISTS `transaccion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transaccion` (
  `id` int NOT NULL AUTO_INCREMENT,
  `monto` int NOT NULL,
  `folio` int NOT NULL,
  `fecha` date NOT NULL,
  `num_cuenta_cliente` int NOT NULL,
  `estado` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `num_cuenta_cliente_idx` (`num_cuenta_cliente`),
  CONSTRAINT `num_cuenta_cliente` FOREIGN KEY (`num_cuenta_cliente`) REFERENCES `cuenta` (`numero_cuenta`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaccion`
--

LOCK TABLES `transaccion` WRITE;
/*!40000 ALTER TABLE `transaccion` DISABLE KEYS */;
INSERT INTO `transaccion` VALUES (4,200,700861,'2024-02-15',3,'Cobrado'),(5,200,993942,'2024-02-15',3,'Cobrado'),(6,200,737205,'2024-02-15',3,'Cobrado'),(7,200,414774,'2024-02-15',3,'Cobrado'),(8,200,768349,'2024-02-15',3,'Cobrado'),(9,200,680017,'2024-02-15',3,'Cobrado'),(10,200,42575,'2024-02-15',3,'Cobrado'),(11,200,30770,'2024-02-15',3,'Cobrado'),(12,200,809102,'2024-02-15',3,'Cobrado'),(13,200,856085,'2024-02-15',3,'Cobrado'),(14,200,124316,'2024-02-15',3,'Cobrado'),(15,200,920200,'2024-02-15',3,'Cobrado'),(16,500,22008,'2024-02-15',2,'Cobrado'),(17,1000,743036,'2024-02-15',3,'Cobrado'),(18,1000,303424,'2024-02-15',3,'Cobrado'),(19,200,135729,'2024-02-15',3,'Cobrado'),(20,200,452327,'2024-02-15',3,'Cobrado'),(21,200,997182,'2024-02-15',3,'Cobrado'),(22,500,614553,'2024-02-15',3,'Cobrado'),(23,400,889062,'2024-02-15',3,'Cobrado'),(24,1000,546321,'2024-02-15',3,'Cobrado'),(25,6565,788266,'2024-02-15',3,'Cobrado'),(26,10,776000,'2024-02-16',3,'Cobrado'),(27,233,458162,'2024-02-16',3,'Cobrado'),(28,150,885886,'2024-02-17',3,'Cobrado'),(29,0,354632,'2024-02-17',3,'Pendiente'),(30,150,435606,'2024-02-17',3,'Pendiente'),(31,150,143609,'2024-02-17',3,'Pendiente'),(32,150,612224,'2024-02-17',3,'Pendiente'),(33,150,173850,'2024-02-17',3,'Pendiente'),(34,150,973108,'2024-02-17',3,'Pendiente'),(35,150,187271,'2024-02-17',3,'Pendiente'),(36,100,59643,'2024-02-17',3,'Pendiente'),(37,500,717087,'2024-02-17',7,'Cobrado'),(38,100,439765,'2024-02-17',3,'Pendiente'),(39,500,38505,'2024-02-17',7,'Pendiente'),(40,2000,956263,'2024-02-18',3,'Pendiente'),(41,2000,549115,'2024-02-18',7,'Pendiente'),(42,2000,947051,'2024-02-18',7,'Pendiente'),(43,2000,947051,'2024-02-18',7,'Pendiente'),(44,2000,592282,'2024-02-18',3,'Pendiente'),(45,2000,203492,'2024-02-18',7,'Pendiente'),(46,2000,648746,'2024-02-18',3,'Pendiente'),(47,2000,302867,'2024-02-18',3,'Pendiente'),(48,2000,479753,'2024-02-18',3,'Pendiente'),(49,2000,361672,'2024-02-18',3,'Cobrado'),(50,500,947788,'2024-02-19',3,'Pendiente'),(51,500,78343,'2024-02-20',7,'Cobrado'),(52,400,738227,'2024-02-20',19,'Pendiente'),(53,20,48976,'2024-02-20',19,'Pendiente'),(54,200000,828255,'2024-02-20',20,'Cobrado'),(55,20000,483874,'2024-02-20',20,'Pendiente'),(56,20000,46699,'2024-02-20',20,'Cobrado'),(57,100,243946,'2024-02-20',7,'Cobrado'),(58,400,959560,'2024-02-20',7,'Cobrado');
/*!40000 ALTER TABLE `transaccion` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizar_saldo_despues_cobro` AFTER UPDATE ON `transaccion` FOR EACH ROW BEGIN
    -- Verificar si el estado de la transacción cambió a 'Cobrado'
    IF NEW.estado = 'Cobrado' AND OLD.estado != 'Cobrado' THEN
        -- Actualizar el saldo de la cuenta
        UPDATE cuenta
        SET saldo = saldo - NEW.monto
        WHERE numero_cuenta = NEW.num_cuenta_cliente;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER `actualizar_saldos` AFTER UPDATE ON `transaccion` FOR EACH ROW BEGIN
    IF NEW.estado = 'Cobrado' THEN
        -- Restar el monto de la transacción de la cuenta de origen
        UPDATE cuenta SET saldo = saldo - NEW.monto WHERE numero_cuenta = NEW.num_cuenta_cliente;
        
        -- Sumar el monto de la transacción a la cuenta de destino
        UPDATE cuenta SET saldo = saldo + NEW.monto WHERE numero_cuenta = (SELECT num_cuenta_destino FROM transferencia WHERE id_transaccion_tra = NEW.id);
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `transferencia`
--

DROP TABLE IF EXISTS `transferencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `transferencia` (
  `id_transaccion_tra` int NOT NULL,
  `num_cuenta_destino` int NOT NULL,
  PRIMARY KEY (`id_transaccion_tra`),
  UNIQUE KEY `id_transaccion_UNIQUE` (`id_transaccion_tra`),
  KEY `num_cuenta_destino_idx` (`num_cuenta_destino`),
  CONSTRAINT `id_transaccion_tra` FOREIGN KEY (`id_transaccion_tra`) REFERENCES `transaccion` (`id`),
  CONSTRAINT `num_cuenta_destino` FOREIGN KEY (`num_cuenta_destino`) REFERENCES `cuenta` (`numero_cuenta`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transferencia`
--

LOCK TABLES `transferencia` WRITE;
/*!40000 ALTER TABLE `transferencia` DISABLE KEYS */;
INSERT INTO `transferencia` VALUES (56,7),(57,7),(49,12),(51,12),(54,12),(58,20);
/*!40000 ALTER TABLE `transferencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'bd_banco'
--

--
-- Dumping routines for database 'bd_banco'
--
/*!50003 DROP PROCEDURE IF EXISTS `ObtenerTransaccionesPorFecha` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerTransaccionesPorFecha`(IN fechaInicio DATE,
    IN fechaFin DATE,
    IN numCuentaCliente INT)
BEGIN
SELECT
	t.id AS id_transaccion,
	t.fecha,
	t.monto,
	t.estado,
    t.num_cuenta_cliente
	FROM transaccion t
	JOIN cuenta c ON t.num_cuenta_cliente = c.numero_cuenta
	WHERE
        c.numero_cuenta = numCuentaCliente
        AND t.fecha BETWEEN fechaInicio AND fechaFin
        ORDER BY
         id_transaccion DESC;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-03-05 21:06:28
