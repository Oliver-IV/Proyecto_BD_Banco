/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.itson.bdavanzadas.bancodominio;

/**
 *
 * @author Oliver Valle
 */
public class Transaccion {
    
    private int id, monto, folio ;
    private String fecha ;
    private int numCuentaCliente ;
    private int numCuentaDestino ;
    private String contrasenia ;

    public Transaccion(int id, int monto, int folio, String fecha, int numCuentaCliente, int numCuentaDestino) {
        this.id = id;
        this.monto = monto;
        this.folio = folio;
        this.fecha = fecha;
        this.numCuentaCliente = numCuentaCliente;
        this.numCuentaDestino = numCuentaDestino ;
    }
    
    public Transaccion(int id, int monto, int folio, String fecha, int numCuentaCliente, String contrasenia) {
        this.id = id;
        this.monto = monto;
        this.folio = folio;
        this.fecha = fecha;
        this.numCuentaCliente = numCuentaCliente;
        this.contrasenia = contrasenia ;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public int getFolio() {
        return folio;
    }

    public void setFolio(int folio) {
        this.folio = folio;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getNumCuentaCliente() {
        return numCuentaCliente;
    }

    public void setNumCuentaCliente(int numCuentaCliente) {
        this.numCuentaCliente = numCuentaCliente;
    }

    public int getNumCuentaDestino() {
        return numCuentaDestino;
    }

    public void setNumCuentaDestino(int numCuentaDestino) {
        this.numCuentaDestino = numCuentaDestino;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    
    
    
}
